import csv
my_file=open("election_data.csv","r",encoding="utf-8")
my_list=list(csv.reader(my_file))


my_count=0
my_candidate_dist=[]
my_candidate_count=[]
my_candidate_pct=[]
my_list.pop(0)
my_max_candidate=""
my_max=0

for x in my_list:
    my_count=my_count+1
    if x[2] not in my_candidate_dist:
        my_candidate_dist.append(x[2])


for i in my_candidate_dist:
    my_can_count=0
    for j in my_list: 
        if j[2]==i:
            my_can_count=my_can_count+1
    my_candidate_count.append(my_can_count)

for z in my_candidate_count:
       pct=round(((z/my_count)*100),3)
       my_candidate_pct.append(pct)



my_summery_list=list(zip(my_candidate_dist,my_candidate_pct,my_candidate_count))

for z in my_summery_list:
        if my_max<z[2]:
                my_max=z[2]
                my_max_candidate=z[0]
 

print("Election Results")
print("---------------------------")
print(f"Total Votes:  {my_count}")
print("---------------------------")
for x in my_summery_list:
        print(f"{x[0]}:  {x[1]}%  ({x[2]})")
print("---------------------------") 
print(f"Winner:  {my_max_candidate}")
print("---------------------------")

my_export_file=open("export_election_result.txt","w")


my_export_file.write("Election Results \n")
my_export_file.write("---------------------------\n")
my_export_file.write(f"Total Votes:  {my_count}\n")
my_export_file.write("---------------------------\n")
for x in my_summery_list:
        my_export_file.write(f"{x[0]}:  {x[1]}%  ({x[2]})\n")
my_export_file.write("---------------------------\n") 
my_export_file.write(f"Winner:  {my_max_candidate}\n")
my_export_file.write("---------------------------")

