#The total number of months included in the dataset
#The net total amount of "Profit/Losses" over the entire period
#The average of the changes in "Profit/Losses" over the entire period
#The greatest increase in profits (date and amount) over the entire period
#The greatest decrease in losses (date and amount) over the entire period

import csv

myfile=open("budget_data.csv","r",newline="",encoding="utf-8")
mylist=list(csv.reader(myfile))

mylist.pop(0)
mycount=0
mynettotal=0
mychanges=0
myprevious=int(mylist[0][1])
mymax=int(mylist[0][1])
mymaxmonth=""
mymin=int(mylist[0][1])
for x in mylist:
    mycount=mycount+1
    mynettotal=int(x[1])+mynettotal
    mychanges=mychanges+int(x[1])-myprevious

    
    if int(x[1])-myprevious>mymax:
        mymax=int(x[1])-myprevious
        mymaxmonth=x[0]
        
    
    if int(x[1])-myprevious<mymin:
        mymin=int(x[1])-myprevious
        myminmonth=x[0]
    

    myprevious=int(x[1])


mytotalchanges=round(mychanges/(mycount-1),2)

print("Financial Analysis")
print("----------------------------")
print(f"Total Months: {mycount}")
print(f"Total: ${mynettotal}")
print(f"Average  Change: ${mytotalchanges}")
print(f"Greatest Increase in Profits: {mymaxmonth} (${mymax})")
print(f"Greatest Decrease in Profits: {myminmonth} (${mymin})")

my_export_file=open("export_budget_result.txt","w")
my_export_file.write("Financial Analysis\n")
my_export_file.write("----------------------------\n")
my_export_file.write(f"Total Months: {mycount}\n")
my_export_file.write(f"Total: ${mynettotal}\n")
my_export_file.write(f"Average  Change: ${mytotalchanges}\n")
my_export_file.write(f"Greatest Increase in Profits: {mymaxmonth} (${mymax})\n")
my_export_file.write(f"Greatest Decrease in Profits: {myminmonth} (${mymin})\n")
    
